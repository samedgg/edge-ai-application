/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <math.h>

/* X-CUBE-AI Libraries */
#include "ai_platform.h"
#include "network.h"
#include "network_data.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
uint8_t ivme_veri[6];
int16_t ham_X, ham_Y, ham_Z;
float ivme_X, ivme_Y, ivme_Z;
float roll=0, pitch=0,yaw=0, roll_acc, pitch_acc;

uint8_t af[6];
int16_t paf_X, paf_Y, paf_Z;

/* 32-bit variables for calibration sums */
int32_t toplam_X = 0, toplam_Y = 0, toplam_Z = 0;
/* Static offset values for calibration */
float offset_X = 0, offset_Y = 0, offset_Z = 0;

float af_X, af_Y, af_Z;

/* X-CUBE-AI Variables */
ai_handle network = AI_HANDLE_NULL;
float ai_input_buffer[400 * 2]; /* Buffer for A_mag and G_mag features */
int sample_counter = 0;

/* System State Control */
int ai_state = 0; /* 0: Waiting for SPACE, 1: Recording, 2: Inference */
uint8_t rx_byte = 0;

/* X-CUBE-AI Memory Allocation */
AI_ALIGNED(32) ai_u8 activations[AI_NETWORK_DATA_ACTIVATIONS_SIZE];
AI_ALIGNED(32) ai_float in_data[AI_NETWORK_IN_1_SIZE];
AI_ALIGNED(32) ai_float out_data[AI_NETWORK_OUT_1_SIZE];

/* X-CUBE-AI I/O Buffers */
ai_buffer *ai_input;
ai_buffer *ai_output;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART2_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
      uint8_t uyan_mesaji = 0x00;
      HAL_I2C_Mem_Write(&hi2c1, 0xD0, 0x6B, 1, &uyan_mesaji, 1, 100);

      //setting limit to 2000 deg/s
      uint8_t gyro_ayar = 0x18;
      HAL_I2C_Mem_Write(&hi2c1, 0xD0, 0x1B, 1, &gyro_ayar, 1, 100);

      /* Read 500 samples for gyro calibration */
      for (int i = 0; i < 500; i++) {
          HAL_I2C_Mem_Read(&hi2c1, 0xD0, 0x43, 1, af, 6, 10);
          paf_X = (int16_t)(af[0] << 8 | af[1]);
          paf_Y = (int16_t)(af[2] << 8 | af[3]);
          paf_Z = (int16_t)(af[4] << 8 | af[5]);
          toplam_X += paf_X;
          toplam_Y += paf_Y;
          toplam_Z += paf_Z;
          HAL_Delay(2);
      }

      offset_X = (toplam_X / 500.0f) / 16.4f;
      offset_Y = (toplam_Y / 500.0f) / 16.4f;
      offset_Z = (toplam_Z / 500.0f) / 16.4f;

      /* Initialize X-CUBE-AI Model */
      char dbg_msg[150];
      sprintf(dbg_msg, "\r\n--- 1. SYSTEM INITIALIZING ---\r\n");
      HAL_UART_Transmit(&huart2, (uint8_t*)dbg_msg, strlen(dbg_msg), 100);

      ai_error ai_err;
      ai_err = ai_network_create(&network, AI_NETWORK_DATA_CONFIG);
      if (ai_err.type != AI_ERROR_NONE) {
          sprintf(dbg_msg, "!!! AI CREATE ERROR: %d !!!\r\n", ai_err.type);
          HAL_UART_Transmit(&huart2, (uint8_t*)dbg_msg, strlen(dbg_msg), 100);
          while(1);
      }

      ai_network_report report;
      ai_network_get_info(network, &report);

      ai_network_params params;
      params.params = report.params;
      params.activations = report.activations;
      params.params.data = AI_HANDLE_PTR(ai_network_data_weights_get());
      params.activations.data = AI_HANDLE_PTR(activations);

      if (!ai_network_init(network, &params)) {
          ai_err = ai_network_get_error(network);
          sprintf(dbg_msg, "!!! AI INIT ERROR - Type: %d, Code: %d !!!\r\n", ai_err.type, ai_err.code);
          HAL_UART_Transmit(&huart2, (uint8_t*)dbg_msg, strlen(dbg_msg), 100);
          while(1);
      }

      ai_input = ai_network_inputs_get(network, NULL);
      ai_output = ai_network_outputs_get(network, NULL);

      sprintf(dbg_msg, "--- 2. AI DEPLOYED SUCCESSFULLY! ---\r\n\n>> Press 'SPACE' to record a gesture...\r\n");
      HAL_UART_Transmit(&huart2, (uint8_t*)dbg_msg, strlen(dbg_msg), 100);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

      if (ai_state == 0)
      {
          /* Poll UART for SPACE key with 10ms timeout */
          if (HAL_UART_Receive(&huart2, &rx_byte, 1, 10) == HAL_OK)
          {
              if (rx_byte == ' ')
              {
                  char msg[] = "\r\n>>> RECORDING STARTED! Draw your shape... (4 Seconds) <<<\r\n";
                  HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
                  sample_counter = 0;
                  ai_state = 1; /* Switch to recording state */
              }
          }
      }
	  else if (ai_state == 1)
			{
				uint8_t buffer_14[14]; /* Single buffer for Accelerometer, Temp, and Gyroscope */

				/* Burst read 14 bytes to eliminate I2C latency */
				HAL_I2C_Mem_Read(&hi2c1, 0xD0, 0x3B, 1, buffer_14, 14, 100);

				/* Extract accelerometer data */
				ham_X = (int16_t)(buffer_14[0] << 8 | buffer_14[1]);
				ham_Y = (int16_t)(buffer_14[2] << 8 | buffer_14[3]);
				ham_Z = (int16_t)(buffer_14[4] << 8 | buffer_14[5]);

				ivme_X = ham_X / 16384.0f;
				ivme_Y = ham_Y / 16384.0f;
				ivme_Z = ham_Z / 16384.0f;

				/* Extract gyroscope data (skip bytes 6-7 for temperature) */
				paf_X = (int16_t)(buffer_14[8] << 8 | buffer_14[9]);
				paf_Y = (int16_t)(buffer_14[10] << 8 | buffer_14[11]);
				paf_Z = (int16_t)(buffer_14[12] << 8 | buffer_14[13]);

				af_X = (paf_X / 16.4f) - offset_X;
				af_Y = (paf_Y / 16.4f) - offset_Y;
				af_Z = (paf_Z / 16.4f) - offset_Z;

				/* Calculate Euclidean Norm for AI input */
				float a_mag = sqrtf(ivme_X * ivme_X + ivme_Y * ivme_Y + ivme_Z * ivme_Z);
				float g_mag = sqrtf(af_X * af_X + af_Y * af_Y + af_Z * af_Z);

				ai_input_buffer[sample_counter * 2 + 0] = a_mag;
				ai_input_buffer[sample_counter * 2 + 1] = g_mag;

				sample_counter++;

				if (sample_counter >= 400)
				{
					ai_state = 2;
				}

				HAL_Delay(8); /* 8ms delay to achieve ~100Hz sampling rate */
			}
      else if (ai_state == 2)
      {
          char ai_msg[] = ">>> [AI INFERENCE RUNNING...]\r\n";
          HAL_UART_Transmit(&huart2, (uint8_t*)ai_msg, strlen(ai_msg), 100);

          /* 1. Copy data to X-CUBE-AI input tensor */
          for (int i = 0; i < (400 * 2); i++) {
              in_data[i] = ai_input_buffer[i];
          }

          /* 2. Bind memory addresses */
          ai_input[0].data = AI_HANDLE_PTR(in_data);
          ai_output[0].data = AI_HANDLE_PTR(out_data);

          /* 3. Run Inference */
          ai_i32 n_batch = ai_network_run(network, ai_input, ai_output);

          if (n_batch == 1)
          {
              /* 4. Find the class with the highest probability */
              float max_prob = -1.0f;
              int predicted_class = -1;

              for (int c = 0; c < 4; c++) {
                  float prob = out_data[c];
                  if (prob > max_prob) {
                      max_prob = prob;
                      predicted_class = c;
                  }
              }

              /* Class Labels (Must match Python training Label Map) */
              const char* sinif_isimleri[] = {
                  "IDLE",
                  "TRIANGLE",
                  "RECTANGLE",
                  "CIRCLE"
              };

              /* Transmit prediction via UART */
              char ai_buffer[150];
              sprintf(ai_buffer, "\r\n>> PREDICTED GESTURE: %s\r\n>> ACCURACY: %%%.2f \r\n\r\n\n>> Press 'SPACE' to record again...\r\n",
                      sinif_isimleri[predicted_class], max_prob * 100.0f);
              HAL_UART_Transmit(&huart2, (uint8_t*)ai_buffer, strlen(ai_buffer), 100);
          }
          else
          {
              char err_buffer[50];
              sprintf(err_buffer, "!!! AI_RUN ERROR: %d !!!\r\n\n", (int)n_batch);
              HAL_UART_Transmit(&huart2, (uint8_t*)err_buffer, strlen(err_buffer), 100);
          }

          /* Reset state machine and UART buffer */
          rx_byte = 0;
          ai_state = 0;
      }

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 100;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
